// test/load-test.ts

import { loadPlugins } from '@mx-core/core';
import { getRules } from '../packages/core/src/rbac/rules.ts';

(async () => {
  await loadPlugins('plugins');
  console.log('✅ Loaded Rules:', getRules());
})();
