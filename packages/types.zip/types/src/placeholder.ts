// packages/types/src/placeholder.ts

export const __types_placeholder = true;
